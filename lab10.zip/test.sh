make clean;make
cat test01.txt | ./labsh
ls
cat test02.txt | ./labsh
ls
cat redirected_file
