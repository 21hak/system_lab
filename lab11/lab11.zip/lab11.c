#include <stdio.h>

#define arr 5
#define process 5

void first(int arraySize[], int processSize[]){
  int allocation[process] = {0};

  // implementation

  //

  for (int i = 0; i < arr ; i++){
    printf("Process %d, Block %d\n", i, allocation[i]);
  }
}

void best(int arraySize[], int processSize[]){
  int allocation[process] = {0};

  // implementation

  //

  for (int i = 0; i < arr ; i++){
    printf("Process %d, Block %d\n", i, allocation[i]);
  }
}

int main()
{
  int arraySize[] = {30, 50, 40, 10, 20};
  int processSize[] = {41, 4, 24, 15, 19};

  first(arraySize,processSize);
  best(arraySize,processSize);
}

