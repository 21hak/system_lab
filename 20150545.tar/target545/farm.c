/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_343()
{
    return 3284633928U;
}

unsigned addval_228(unsigned x)
{
    return x + 3284633929U;
}

unsigned addval_236(unsigned x)
{
    return x + 3284633928U;
}

unsigned addval_432(unsigned x)
{
    return x + 3277348376U;
}

void setval_119(unsigned *p)
{
    *p = 881640280U;
}

unsigned getval_287()
{
    return 2496104776U;
}

unsigned getval_261()
{
    return 2425444404U;
}

unsigned addval_296(unsigned x)
{
    return x + 2455301321U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

void setval_232(unsigned *p)
{
    *p = 3682910857U;
}

void setval_134(unsigned *p)
{
    *p = 3223376269U;
}

unsigned getval_274()
{
    return 3678982537U;
}

unsigned addval_239(unsigned x)
{
    return x + 3374895497U;
}

void setval_390(unsigned *p)
{
    *p = 3677930113U;
}

unsigned getval_293()
{
    return 3676360329U;
}

unsigned addval_409(unsigned x)
{
    return x + 3286272328U;
}

unsigned addval_396(unsigned x)
{
    return x + 3526938241U;
}

unsigned getval_278()
{
    return 3221802637U;
}

unsigned addval_485(unsigned x)
{
    return x + 3281178249U;
}

unsigned getval_334()
{
    return 2425409929U;
}

void setval_255(unsigned *p)
{
    *p = 3281113481U;
}

unsigned addval_252(unsigned x)
{
    return x + 3252717896U;
}

unsigned addval_378(unsigned x)
{
    return x + 3286272456U;
}

void setval_294(unsigned *p)
{
    *p = 3676357129U;
}

void setval_362(unsigned *p)
{
    *p = 3373846153U;
}

unsigned getval_163()
{
    return 3525362377U;
}

unsigned getval_271()
{
    return 2430634314U;
}

unsigned addval_243(unsigned x)
{
    return x + 3767093410U;
}

unsigned addval_324(unsigned x)
{
    return x + 3269495112U;
}

unsigned getval_138()
{
    return 3674787457U;
}

unsigned addval_383(unsigned x)
{
    return x + 3372794497U;
}

void setval_168(unsigned *p)
{
    *p = 3682914699U;
}

unsigned getval_291()
{
    return 3281047177U;
}

void setval_207(unsigned *p)
{
    *p = 2429651429U;
}

void setval_348(unsigned *p)
{
    *p = 3677933977U;
}

unsigned getval_192()
{
    return 2497743176U;
}

void setval_460(unsigned *p)
{
    *p = 3376988809U;
}

unsigned addval_498(unsigned x)
{
    return x + 2430634328U;
}

unsigned addval_217(unsigned x)
{
    return x + 3676357129U;
}

unsigned getval_452()
{
    return 3372797579U;
}

unsigned addval_191(unsigned x)
{
    return x + 3229926025U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
